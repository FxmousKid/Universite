public class TranstypagesObjets {
    public static void main(String[] args) {
        Object vObject = new Object();
        Integer vInteger = 42;
        String vString = "coucou";
        System.out.println("vObject = " + vObject +
                ", vInteger = " + vInteger +
                ", vString = " + vString);
    }
}
